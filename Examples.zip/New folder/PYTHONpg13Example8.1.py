a,b=2,1
if(a>b):
    print(a) #tab is used
    print("This is printed because if condition is true")
print(b)
import gradecalcfunc
import sys

argv = ['Amal','Kamal','Nimal']

name1 = argv[0]
name2 = argv[1]
name3 = argv[2]

mark1 = sys.argv[1]
mark2 = sys.argv[2]
mark3 = sys.argv[3]

mark1 = int(mark1)
mark2 = int(mark2)
mark3 = int(mark3)

gradecalcfunc.grade(name1,mark1)
gradecalcfunc.grade(name2,mark2)
gradecalcfunc.grade(name3,mark3)

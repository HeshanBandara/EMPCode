# Python program to execute
# function directly
def my_function():
	print ("I am inside function")

# We can test function by calling it.
# my_function()

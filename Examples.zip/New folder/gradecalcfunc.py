# x=60
# if x>50:
#     grade="Pass"
# else:
#     grade="Fail"
# print(grade)

def grade(x,y):
    
    if y>85:
        grade="A++"
    elif y>50:
        grade="Pass"
    else:
        grade="Fail"

    print(x," is",grade)

a=1
b=2
print (id(a))
print (id(b))
print (type(a))
print (a is b)

# grade(40)
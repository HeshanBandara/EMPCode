#Examples.py
#First Examples

count = 1
while count<=5:
    x=input(
        "Enter a String: ")
    char_count=\
    len(x) #compute the length
    print("String: ",x," | length: ",char_count)
    count = count + 1
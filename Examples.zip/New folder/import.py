# Python program to use
# main for function call.
#my_function()  #'my_function' is not defined

# import ex1
# import ex2

import main

# ex2.my_function()

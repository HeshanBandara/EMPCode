a=5
b=2.5
c=5/2.5
print(type(a))
print(type(b))
print(type(c))
print(c)
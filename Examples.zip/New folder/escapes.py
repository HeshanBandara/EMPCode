a = "This is string"
b = "Thi\\s is string"
c = "Thi\ns is string"
d = "Thi\rs is string"
e = "Thi\ts is string"

print(a)
print(b)
print(c)
print(d)
print(e)